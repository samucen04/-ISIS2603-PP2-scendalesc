/* tslint:disable:no-unused-variable */

import { TestBed, inject } from '@angular/core/testing';
import { NavesService } from './nave.service';

describe('Service: Nave', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NavesService]
    });
  });

  it('should ...', inject([NavesService], (service: NavesService) => {
    expect(service).toBeTruthy();
  }));
});
function beforeEach(arg0: () => void) {
  throw new Error('Function not implemented.');
}

