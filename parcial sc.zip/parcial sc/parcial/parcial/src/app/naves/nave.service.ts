import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment.development';
import { Nave } from './Nave'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavesService {
  getNaves() {
    throw new Error('Method not implemented.');
  }

  private apiUrl: string = environment.baseUrl;


  constructor(private http: HttpClient) { }

  getSeries(): Observable<Nave[]> {
    return this.http.get<Nave[]>(this.apiUrl);
  }

}
