import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavesListComponent } from './naves-list/naves-list.component';

@NgModule({
  imports: [
    CommonModule
  ],
  exports: [NavesListComponent],
  declarations: [NavesListComponent]
})
export class NavesModule { }
