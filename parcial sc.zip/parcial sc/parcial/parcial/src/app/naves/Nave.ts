export class Nave {
    name: string;
    fabricante: string;
    descripcion: string;
    showLink: string;
    imageLink: string;

    constructor(name: string, fabricante: string, descripcion: string, link: string, image: string) {
        this.name = name;
        this.fabricante = fabricante;
        this.descripcion = descripcion;
        this.showLink = link;
        this.imageLink = image;

    }
}
