import { Component, OnInit } from '@angular/core';
import { Nave } from '../Nave';
import { NavesService } from '../nave.service';

@Component({
  selector: 'app-naves-list',
  templateUrl: './naves-list.component.html',
  styleUrls: ['./naves-list.component.css']
})
export class NavesListComponent implements OnInit {

  naves: Nave[] = [];
  series: any;
  seasonsAvarage: number;

  constructor(private naveService: NavesService) { }

  ngOnInit() {
    this.getNaves();
  }

  getNaves(): void {
    this.naveService.getNaves().subscribe((naves) => {
      this.naves = naves;
    });
  }
}
