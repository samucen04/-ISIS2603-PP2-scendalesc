const baseUrl =
    'https://raw.githubusercontent.com/2603-Uniandes/jsons/main/2024-10%20Star%20Wars/spaceships.json';

export const environment = {
    production: false,
    baseUrl
};

